package com.example.stoper;

import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView stoperTime;
    private boolean stoperRunning = false;
    private long stoperStartTime = 0L;
    private Handler stoperHandler = new Handler();
    private Runnable stoperRunnable;

    private TextView minutnikTime;
    private EditText minutyInput, sekundyInput;
    private boolean minutnikRunning = false;
    private long minutnikMillisLeft = 0L;
    private Handler minutnikHandler = new Handler();
    private Runnable minutnikRunnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        stoperTime = findViewById(R.id.stoperTime);
        Button stoperStart = findViewById(R.id.stoperStart);
        Button stoperPause = findViewById(R.id.stoperPause);
        Button stoperReset = findViewById(R.id.stoperReset);

        stoperRunnable = new Runnable() {
            @Override
            public void run() {
                if (stoperRunning) {
                    long elapsed = System.currentTimeMillis() - stoperStartTime;
                    int minutes = (int) (elapsed / 60000);
                    int seconds = (int) (elapsed / 1000) % 60;
                    int hundredths = (int) (elapsed % 1000) / 10;
                    stoperTime.setText(String.format("%02d:%02d.%02d", minutes, seconds, hundredths));
                    stoperHandler.postDelayed(this, 10);
                }
            }
        };

        stoperStart.setOnClickListener(v -> {
            if (!stoperRunning) {
                stoperRunning = true;
                stoperStartTime = System.currentTimeMillis() - getElapsedFromText(stoperTime.getText().toString());
                stoperHandler.post(stoperRunnable);
            }
        });

        stoperPause.setOnClickListener(v -> stoperRunning = false);

        stoperReset.setOnClickListener(v -> {
            stoperRunning = false;
            stoperTime.setText("00:00.00");
        });

        minutnikTime = findViewById(R.id.minutnikTime);
        minutyInput = findViewById(R.id.minutyInput);
        sekundyInput = findViewById(R.id.sekundyInput);
        Button minutnikStart = findViewById(R.id.minutnikStart);
        Button minutnikPause = findViewById(R.id.minutnikPause);
        Button minutnikReset = findViewById(R.id.minutnikReset);

        minutnikRunnable = new Runnable() {
            @Override
            public void run() {
                if (minutnikRunning && minutnikMillisLeft > 0) {
                    minutnikMillisLeft -= 100;
                    int minutes = (int) (minutnikMillisLeft / 60000);
                    int seconds = (int) (minutnikMillisLeft / 1000) % 60;
                    int tenths = (int) (minutnikMillisLeft % 1000) / 100;
                    minutnikTime.setText(String.format("%02d:%02d.%d", minutes, seconds, tenths));
                    minutnikHandler.postDelayed(this, 100);
                } else {
                    minutnikRunning = false;
                }
            }
        };

        minutnikStart.setOnClickListener(v -> {
            if (!minutnikRunning) {
                if (minutnikMillisLeft == 0) {
                    int minuty = parseInt(minutyInput.getText().toString());
                    int sekundy = parseInt(sekundyInput.getText().toString());
                    minutnikMillisLeft = (minuty * 60 + sekundy) * 1000L;
                }
                minutnikRunning = true;
                minutnikHandler.post(minutnikRunnable);
            }
        });

        minutnikPause.setOnClickListener(v -> minutnikRunning = false);

        minutnikReset.setOnClickListener(v -> {
            minutnikRunning = false;
            minutnikMillisLeft = 0;
            minutnikTime.setText("00:00.0");
        });
    }

    private long getElapsedFromText(String timeText) {
        String[] parts = timeText.split("[:.]");
        int min = Integer.parseInt(parts[0]);
        int sec = Integer.parseInt(parts[1]);
        int hundredths = Integer.parseInt(parts[2]);
        return (min * 60000L + sec * 1000L + hundredths * 10L);
    }

    private int parseInt(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
