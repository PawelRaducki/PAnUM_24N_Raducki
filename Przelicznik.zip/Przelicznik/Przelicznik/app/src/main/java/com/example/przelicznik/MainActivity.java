package com.example.przelicznik;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText inputValue;
    private TextView outputValue;
    private Spinner conversionSpinner;
    private Button convertButton;

    private String[] conversions = {
            "złotówki na euro",
            "euro na złotówki",
            "centymetry na cale",
            "cale na centymetry",
            "stopnie Celsjusza na Fahrenheita",
            "Fahrenheita na stopnie Celsjusza",
            "kilometry na mile",
            "mile na kilometry"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputValue = findViewById(R.id.inputValue);
        outputValue = findViewById(R.id.outputValue);
        conversionSpinner = findViewById(R.id.conversionSpinner);
        convertButton = findViewById(R.id.convertButton);

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, conversions);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        conversionSpinner.setAdapter(adapter);

        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                performConversion();
            }
        });
    }

    private void performConversion() {
        String inputText = inputValue.getText().toString().trim();
        if (TextUtils.isEmpty(inputText)) {
            Toast.makeText(this, "Proszę podać dane", Toast.LENGTH_SHORT).show();
            return;
        }

        String[] values = inputText.split(",");
        StringBuilder resultBuilder = new StringBuilder();

        int conversionType = conversionSpinner.getSelectedItemPosition();

        for (String val : values) {
            val = val.trim();
            if (val.isEmpty()) continue;

            try {
                double number = Double.parseDouble(val);
                double converted = convert(number, conversionType);

                resultBuilder.append(String.format("%.2f", converted)).append(", ");
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Niepoprawna liczba: " + val, Toast.LENGTH_SHORT).show();
                return;
            }
        }

        if (resultBuilder.length() > 2) {
            resultBuilder.setLength(resultBuilder.length() - 2);
        }

        outputValue.setText(resultBuilder.toString());
    }

    private double convert(double value, int conversionType) {
        switch (conversionType) {
            case 0:
                return value / 4.5;
            case 1:
                return value * 4.5;
            case 2:
                return value / 2.54;
            case 3:
                return value * 2.54;
            case 4:
                return value * 9 / 5 + 32;
            case 5:
                return (value - 32) * 5 / 9;
            case 6:
                return value / 1.609;
            case 7:
                return value * 1.609;
            default:
                return value;
        }
    }
}
