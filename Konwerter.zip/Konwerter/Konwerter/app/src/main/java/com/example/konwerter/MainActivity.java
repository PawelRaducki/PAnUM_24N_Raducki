package com.example.konwerter;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private EditText inputArabic, inputRoman;
    private Button convertToRoman, convertToArabic;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputArabic = findViewById(R.id.inputArabic);
        inputRoman = findViewById(R.id.inputRoman);
        convertToRoman = findViewById(R.id.convertToRoman);
        convertToArabic = findViewById(R.id.convertToArabic);

        convertToRoman.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String arabicInput = inputArabic.getText().toString().trim();
                if (arabicInput.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Podaj liczbę arabską", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    int number = Integer.parseInt(arabicInput);
                    if (number <= 0 || number > 3999) {
                        Toast.makeText(MainActivity.this, "Zakres: 1–3999", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    inputRoman.setText(arabicToRoman(number));
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "Nieprawidłowy format liczby", Toast.LENGTH_SHORT).show();
                }
            }
        });

        convertToArabic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String romanInput = inputRoman.getText().toString().toUpperCase().trim();
                if (romanInput.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Podaj liczbę rzymską", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    int arabic = romanToArabic(romanInput);
                    inputArabic.setText(String.valueOf(arabic));
                } catch (IllegalArgumentException e) {
                    Toast.makeText(MainActivity.this, "Nieprawidłowa liczba rzymska", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private String arabicToRoman(int num) {
        LinkedHashMap<String, Integer> map = new LinkedHashMap<>();
        map.put("M", 1000);
        map.put("CM", 900);
        map.put("D", 500);
        map.put("CD", 400);
        map.put("C", 100);
        map.put("XC", 90);
        map.put("L", 50);
        map.put("XL", 40);
        map.put("X", 10);
        map.put("IX", 9);
        map.put("V", 5);
        map.put("IV", 4);
        map.put("I", 1);

        StringBuilder result = new StringBuilder();
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            while (num >= entry.getValue()) {
                result.append(entry.getKey());
                num -= entry.getValue();
            }
        }
        return result.toString();
    }

    private int romanToArabic(String roman) {
        Map<Character, Integer> map = new LinkedHashMap<>();
        map.put('I', 1);
        map.put('V', 5);
        map.put('X', 10);
        map.put('L', 50);
        map.put('C', 100);
        map.put('D', 500);
        map.put('M', 1000);

        int total = 0;
        int prev = 0;

        for (int i = roman.length() - 1; i >= 0; i--) {
            Integer value = map.get(roman.charAt(i));
            if (value == null)
                throw new IllegalArgumentException("Nieprawidłowy znak: " + roman.charAt(i));

            if (value < prev)
                total -= value;
            else
                total += value;

            prev = value;
        }
        return total;
    }
}
