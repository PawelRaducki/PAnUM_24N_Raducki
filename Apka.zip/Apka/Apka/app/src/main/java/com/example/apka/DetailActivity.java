package com.example.apka;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class DetailActivity extends AppCompatActivity {

    private EditText editTextDetail;
    private Button buttonSave, buttonDelete, buttonSendEmail;
    private DBHelper dbHelper;
    private Item item;
    private boolean isNewNote = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        editTextDetail = findViewById(R.id.editTextDetail);
        buttonSave = findViewById(R.id.buttonSave);
        buttonDelete = findViewById(R.id.buttonDelete);
        buttonSendEmail = findViewById(R.id.buttonSendEmail);

        dbHelper = new DBHelper(this);

        Intent intent = getIntent();
        item = (Item) intent.getSerializableExtra("item");

        if (item != null) {
            isNewNote = false;
            editTextDetail.setText(item.getText());
        } else {
            buttonDelete.setEnabled(false);
        }

        buttonSave.setOnClickListener(v -> {
            String newText = editTextDetail.getText().toString().trim();
            if (newText.isEmpty()) {
                finish();
                return;
            }
            if (isNewNote) {
                dbHelper.addItem(newText);
            } else {
                dbHelper.updateItem(item.getId(), newText);
            }
            finish();
        });

        buttonDelete.setOnClickListener(v -> {
            if (!isNewNote) {
                dbHelper.deleteItem(item.getId());
            }
            finish();
        });

        buttonSendEmail.setOnClickListener(v -> {
            String subject = "Notatka";
            String body = editTextDetail.getText().toString();

            Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
            emailIntent.setData(Uri.parse("mailto:"));
            emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
            emailIntent.putExtra(Intent.EXTRA_TEXT, body);

            if (emailIntent.resolveActivity(getPackageManager()) != null) {
                startActivity(emailIntent);
            }
        });
    }
}
