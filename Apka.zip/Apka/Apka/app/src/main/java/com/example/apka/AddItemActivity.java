package com.example.apka;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class AddItemActivity extends AppCompatActivity {

    private EditText editText;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_item);

        editText = findViewById(R.id.editTextAdd);
        Button buttonAdd = findViewById(R.id.buttonAdd);

        dbHelper = new DBHelper(this);

        buttonAdd.setOnClickListener(v -> {
            String text = editText.getText().toString();
            if (!text.isEmpty()) {
                dbHelper.addItem(text);
                finish();
            }
        });
    }
}
