package com.example.kafeteria;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import androidx.appcompat.app.AppCompatActivity;

public class DrinksActivity extends AppCompatActivity {

    CheckBox checkboxLatte, checkboxCappuccino, checkboxFilter;
    Button buttonOrder;

    PodsumowanieZamowienia podsumowanie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drinks);

        podsumowanie = PodsumowanieZamowienia.getInstance();

        checkboxLatte = findViewById(R.id.checkboxLatte);
        checkboxCappuccino = findViewById(R.id.checkboxCappuccino);
        checkboxFilter = findViewById(R.id.checkboxFilter);
        buttonOrder = findViewById(R.id.buttonOrder);

        loadCheckboxStates();

        buttonOrder.setOnClickListener(v -> {
            updateOrderFromCheckboxes();
            startActivity(new Intent(DrinksActivity.this, PodsumowanieActivity.class));
        });
    }

    private void loadCheckboxStates() {
        checkboxLatte.setChecked(podsumowanie.contains("Latte - 10 zł"));
        checkboxCappuccino.setChecked(podsumowanie.contains("Cappuccino - 11 zł"));
        checkboxFilter.setChecked(podsumowanie.contains("Filter - 9 zł"));
    }

    private void updateOrderFromCheckboxes() {
        if (checkboxLatte.isChecked())
            podsumowanie.addItem("Latte - 10 zł");
        else
            podsumowanie.removeItem("Latte - 10 zł");

        if (checkboxCappuccino.isChecked())
            podsumowanie.addItem("Cappuccino - 11 zł");
        else
            podsumowanie.removeItem("Cappuccino - 11 zł");

        if (checkboxFilter.isChecked())
            podsumowanie.addItem("Filter - 9 zł");
        else
            podsumowanie.removeItem("Filter - 9 zł");
    }
}
