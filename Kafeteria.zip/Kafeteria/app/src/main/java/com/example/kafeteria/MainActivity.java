package com.example.kafeteria;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button buttonDrinks, buttonSnacks, buttonLocations;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonDrinks = findViewById(R.id.buttonDrinks);
        buttonSnacks = findViewById(R.id.buttonSnacks);
        buttonLocations = findViewById(R.id.buttonLocations);

        buttonDrinks.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, DrinksActivity.class);
            startActivity(intent);
        });

        buttonSnacks.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, SnacksActivity.class);
            startActivity(intent);
        });

        buttonLocations.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, LocationsActivity.class);
            startActivity(intent);
        });
    }
}
