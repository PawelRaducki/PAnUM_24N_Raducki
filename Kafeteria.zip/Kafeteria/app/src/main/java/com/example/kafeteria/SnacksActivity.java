package com.example.kafeteria;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import androidx.appcompat.app.AppCompatActivity;

public class SnacksActivity extends AppCompatActivity {

    CheckBox checkboxSzarlotka, checkboxCiastoBananowe, checkboxKremowka;
    Button buttonOrderSnacks;

    PodsumowanieZamowienia podsumowanie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_snacks);

        podsumowanie = PodsumowanieZamowienia.getInstance();

        checkboxSzarlotka = findViewById(R.id.checkboxSzarlotka);
        checkboxCiastoBananowe = findViewById(R.id.checkboxCiastoBananowe);
        checkboxKremowka = findViewById(R.id.checkboxKremowka);
        buttonOrderSnacks = findViewById(R.id.buttonOrderSnacks);

        loadCheckboxStates();

        buttonOrderSnacks.setOnClickListener(v -> {
            updateOrderFromCheckboxes();
            startActivity(new Intent(SnacksActivity.this, PodsumowanieActivity.class));
        });
    }

    private void loadCheckboxStates() {
        checkboxSzarlotka.setChecked(podsumowanie.contains("Szarlotka - 8 zł"));
        checkboxCiastoBananowe.setChecked(podsumowanie.contains("Ciasto bananowe - 9 zł"));
        checkboxKremowka.setChecked(podsumowanie.contains("Kremówka - 10 zł"));
    }

    private void updateOrderFromCheckboxes() {
        if (checkboxSzarlotka.isChecked())
            podsumowanie.addItem("Szarlotka - 8 zł");
        else
            podsumowanie.removeItem("Szarlotka - 8 zł");

        if (checkboxCiastoBananowe.isChecked())
            podsumowanie.addItem("Ciasto bananowe - 9 zł");
        else
            podsumowanie.removeItem("Ciasto bananowe - 9 zł");

        if (checkboxKremowka.isChecked())
            podsumowanie.addItem("Kremówka - 10 zł");
        else
            podsumowanie.removeItem("Kremówka - 10 zł");
    }
}

