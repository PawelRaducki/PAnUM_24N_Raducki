package com.example.kafeteria;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class PodsumowanieZamowienia {
    private static PodsumowanieZamowienia instance;
    private final Set<String> orderItems = new HashSet<>();

    private PodsumowanieZamowienia() {}

    public static synchronized PodsumowanieZamowienia getInstance() {
        if (instance == null) {
            instance = new PodsumowanieZamowienia();
        }
        return instance;
    }

    public void addItem(String item) {
        orderItems.add(item);
    }

    public void removeItem(String item) {
        orderItems.remove(item);
    }

    public void clearOrder() {
        orderItems.clear();
    }

    public List<String> getOrderItems() {
        return new ArrayList<>(orderItems);
    }

    public int getTotalPrice() {
        int total = 0;
        for (String item : orderItems) {
            try {
                String[] parts = item.split(" ");
                String priceStr = parts[parts.length - 2].replace("zł", "").trim();
                total += Integer.parseInt(priceStr);
            } catch (Exception ignored) {}
        }
        return total;
    }

    public boolean contains(String item) {
        return orderItems.contains(item);
    }
}
