package com.example.kafeteria;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class PodsumowanieActivity extends AppCompatActivity {

    ListView listViewPodsumowanie;
    TextView textViewCalkowitaCena;
    Button buttonWyczysc, buttonWroc;

    PodsumowanieZamowienia podsumowanie;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_podsumowanie);

        podsumowanie = PodsumowanieZamowienia.getInstance();

        listViewPodsumowanie = findViewById(R.id.listViewPodsumowanie);
        textViewCalkowitaCena = findViewById(R.id.textViewCalkowitaCena);
        buttonWyczysc = findViewById(R.id.buttonWyczysc);
        buttonWroc = findViewById(R.id.buttonWroc);

        updateSummary();

        buttonWyczysc.setOnClickListener(v -> {
            podsumowanie.clearOrder();
            updateSummary();
        });

        buttonWroc.setOnClickListener(v -> finish());
    }

    private void updateSummary() {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, podsumowanie.getOrderItems());
        listViewPodsumowanie.setAdapter(adapter);

        textViewCalkowitaCena.setText("Razem: " + podsumowanie.getTotalPrice() + " zł");
    }
}
